var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/radar.js
var radar_exports = {};
__export(radar_exports, {
  config: () => config,
  default: () => radar_default
});
module.exports = __toCommonJS(radar_exports);
var BASE = "https://www.aemet.es/es/api-eltiempo/radar/imagen-radar/compo/";
var NOMBRE = /^radw\d{12}_3857\.png$/;
var radar_default = async (request) => {
  const f = new URL(request.url).searchParams.get("f") || "";
  if (!NOMBRE.test(f)) {
    return new Response("nombre de imagen no permitido", {
      status: 400,
      headers: { "access-control-allow-origin": "*" }
    });
  }
  try {
    const r = await fetch(BASE + f);
    if (!r.ok) {
      return new Response("", {
        status: r.status,
        headers: { "access-control-allow-origin": "*", "cache-control": "no-store" }
      });
    }
    return new Response(await r.arrayBuffer(), {
      status: 200,
      headers: {
        "content-type": "image/png",
        "access-control-allow-origin": "*",
        "cache-control": "public, max-age=120",
        "netlify-cdn-cache-control": "public, s-maxage=300, stale-while-revalidate=600",
        "x-origen": "aemet"
      }
    });
  } catch (e) {
    return new Response(String(e.message || e), {
      status: 502,
      headers: { "access-control-allow-origin": "*", "cache-control": "no-store" }
    });
  }
};
var config = { path: "/radar-aemet" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
