var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/mareas.js
var mareas_exports = {};
__export(mareas_exports, {
  config: () => config,
  default: () => mareas_default
});
module.exports = __toCommonJS(mareas_exports);
var FUENTE = "https://www.euskalmet.euskadi.eus/vamet/sea/es/webmet00-latest.html";
var PAGINA = "https://www.euskalmet.euskadi.eus/la-mar/euskadi/";
var RE = /(\d{8}):(\d{2}):(\d{2}):(\d{2}):(high|low)#(-?\d+(?:[.,]\d+)?)/g;
var mareas_default = async () => {
  try {
    const r = await fetch(FUENTE, {
      headers: { "user-agent": "AitorMeteo/1.0", accept: "text/html" },
      signal: AbortSignal.timeout(7e3)
    });
    if (!r.ok) return json({ error: true, reason: `Euskalmet respondi\xF3 ${r.status}` }, 502);
    const txt = await r.text();
    const vistos = /* @__PURE__ */ new Set();
    const dias = /* @__PURE__ */ new Map();
    for (const m of txt.matchAll(RE)) {
      const [, comp, hh, mm, , tipo, alt] = m;
      const fecha = `${comp.slice(0, 4)}-${comp.slice(4, 6)}-${comp.slice(6, 8)}`;
      const hora = `${hh}:${mm}`;
      const clave = `${fecha}|${hora}|${tipo}`;
      if (vistos.has(clave)) continue;
      vistos.add(clave);
      const altura = Number(String(alt).replace(",", "."));
      if (!Number.isFinite(altura)) continue;
      if (!dias.has(fecha)) dias.set(fecha, []);
      dias.get(fecha).push({
        hora,
        altura,
        tipo,
        etiqueta: tipo === "high" ? "Pleamar" : "Bajamar"
      });
    }
    if (!dias.size) return json({ error: true, reason: "Euskalmet no ha publicado mareas" }, 502);
    const salida = [...dias.entries()].map(([fecha, eventos]) => ({ fecha, eventos: eventos.sort((a, b) => a.hora.localeCompare(b.hora)) })).sort((a, b) => a.fecha.localeCompare(b.fecha));
    return json({
      oficial: true,
      fuente: "Euskalmet \xB7 La mar",
      pagina: PAGINA,
      referencia: "altura sobre el cero del puerto, publicada por Euskalmet",
      husoHorario: "hora oficial peninsular",
      consultado: (/* @__PURE__ */ new Date()).toISOString(),
      dias: salida
    }, 200);
  } catch (e) {
    return json({ error: true, reason: String(e.message || e) }, 502);
  }
};
function json(cuerpo, status) {
  const ok = status === 200;
  return new Response(JSON.stringify(cuerpo), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "access-control-allow-origin": "*",
      // Las mareas de tres días no cambian en horas: se cachean de sobra.
      // `stale-if-error` es lo importante: si Euskalmet no responde, el CDN
      // sirve la última tabla buena en vez de dejarle sin mareas. Una tabla
      // de hace unas horas sigue siendo la tabla oficial correcta; un 502
      // no le sirve para nada a quien va a salir a la mar.
      "cache-control": ok ? "public, max-age=1800" : "no-store",
      "netlify-cdn-cache-control": ok ? "public, s-maxage=10800, stale-while-revalidate=21600, stale-if-error=86400" : "public, s-maxage=0, stale-if-error=86400",
      "x-origen": "euskalmet"
    }
  });
}
var config = { path: "/mareas" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
