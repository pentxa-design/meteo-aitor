var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/omtiles.js
var omtiles_exports = {};
__export(omtiles_exports, {
  config: () => config,
  default: () => omtiles_default
});
module.exports = __toCommonJS(omtiles_exports);
var BASE = "https://map-tiles.open-meteo.com/data_spatial";
var omtiles_default = async (request) => {
  const url = new URL(request.url);
  const ruta = url.pathname.replace(/^\/omtiles\//, "");
  if (!ruta || ruta.includes("..")) {
    return new Response("ruta no v\xE1lida", { status: 400 });
  }
  const destino = `${BASE}/${ruta}${url.search}`;
  const cab = { accept: "*/*" };
  const range = request.headers.get("range");
  if (range) cab.range = range;
  try {
    const r = await fetch(destino, { headers: cab });
    const buf = await r.arrayBuffer();
    const esMeta = ruta.endsWith(".json");
    const salida = new Headers();
    for (const h of [
      "content-type",
      "content-length",
      "content-range",
      "accept-ranges",
      "etag",
      "last-modified"
    ]) {
      const v = r.headers.get(h);
      if (v) salida.set(h, v);
    }
    if (!salida.has("content-type")) {
      salida.set("content-type", esMeta ? "application/json" : "application/octet-stream");
    }
    salida.set("access-control-allow-origin", "*");
    salida.set(
      "access-control-expose-headers",
      "Content-Range, Content-Length, ETag, Accept-Ranges"
    );
    if (r.ok || r.status === 206) {
      salida.set("cache-control", esMeta ? "public, max-age=60" : "public, max-age=300");
      salida.set("netlify-cdn-cache-control", esMeta ? "public, s-maxage=120, stale-while-revalidate=600" : "public, s-maxage=86400, stale-while-revalidate=604800");
    } else {
      salida.set("cache-control", "no-store");
    }
    salida.set("x-origen", "open-meteo-tiles");
    return new Response(buf, { status: r.status, headers: salida });
  } catch (e) {
    return new Response(JSON.stringify({ error: true, reason: String(e.message || e) }), {
      status: 502,
      headers: { "content-type": "application/json", "access-control-allow-origin": "*" }
    });
  }
};
var config = { path: "/omtiles/*" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
