var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/om.js
var om_exports = {};
__export(om_exports, {
  config: () => config,
  default: () => om_default
});
module.exports = __toCommonJS(om_exports);
var PERMITIDOS = {
  fc: "https://api.open-meteo.com/v1/forecast",
  aq: "https://air-quality-api.open-meteo.com/v1/air-quality",
  marine: "https://marine-api.open-meteo.com/v1/marine",
  geo: "https://geocoding-api.open-meteo.com/v1/search",
  elev: "https://api.open-meteo.com/v1/elevation"
};
var CACHE = { fc: 600, aq: 900, marine: 900, geo: 86400, elev: 2592e3 };
var om_default = async (request) => {
  const entrada = new URL(request.url);
  const cual = entrada.searchParams.get("api") || "fc";
  const destino = PERMITIDOS[cual];
  if (!destino) {
    return new Response(
      JSON.stringify({ error: true, reason: "api no permitida" }),
      { status: 400, headers: { "content-type": "application/json" } }
    );
  }
  const url = new URL(destino);
  for (const [k, v] of entrada.searchParams) if (k !== "api") url.searchParams.append(k, v);
  try {
    const r = await fetch(url, { headers: { "accept": "application/json" } });
    const cuerpo = await r.text();
    const segundos = CACHE[cual] ?? 600;
    return new Response(cuerpo, {
      status: r.status,
      headers: {
        "content-type": "application/json; charset=utf-8",
        "access-control-allow-origin": "*",
        // Solo se cachea lo que ha ido bien: un error no debe quedarse pegado
        "cache-control": r.ok ? `public, max-age=60` : "no-store",
        "netlify-cdn-cache-control": r.ok ? `public, s-maxage=${segundos}, stale-while-revalidate=${segundos * 6}` : "no-store",
        "x-origen": "open-meteo"
      }
    });
  } catch (e) {
    return new Response(
      JSON.stringify({ error: true, reason: String(e.message || e) }),
      { status: 502, headers: { "content-type": "application/json", "access-control-allow-origin": "*" } }
    );
  }
};
var config = { path: "/om" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
