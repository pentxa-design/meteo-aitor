var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/estaciones.js
var estaciones_exports = {};
__export(estaciones_exports, {
  config: () => config,
  default: () => estaciones_default
});
module.exports = __toCommonJS(estaciones_exports);
function caducidad(clave) {
  try {
    const p = String(clave).split(".");
    if (p.length !== 3) return null;
    const pad = p[1] + "=".repeat((4 - p[1].length % 4) % 4);
    const d = JSON.parse(Buffer.from(pad.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
    if (!d.exp) return null;
    const dias = Math.round((d.exp * 1e3 - Date.now()) / 864e5);
    return { fecha: new Date(d.exp * 1e3).toISOString().slice(0, 10), dias };
  } catch {
    return null;
  }
}
var API = "https://opendata.aemet.es/opendata/api/observacion/convencional/todas";
var num = (v, min, max, def) => {
  const n = Number(v);
  return Number.isFinite(n) && n >= min && n <= max ? n : def;
};
var km = (aLat, aLon, bLat, bLon) => {
  const R = 6371, r = Math.PI / 180;
  const dLat = (bLat - aLat) * r, dLon = (bLon - aLon) * r;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(aLat * r) * Math.cos(bLat * r) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
};
var estaciones_default = async (request) => {
  const clave = process.env.AEMET_KEY;
  const p = new URL(request.url).searchParams;
  const lat = num(p.get("lat"), -90, 90, null);
  const lon = num(p.get("lon"), -180, 180, null);
  const radio = num(p.get("radio"), 5, 200, 60);
  const limite = num(p.get("limite"), 1, 20, 6);
  if (!clave) return json({ error: true, sinClave: true, reason: "Falta la clave de AEMET" }, 503);
  if (lat === null || lon === null) return json({ error: true, reason: "faltan lat y lon" }, 400);
  try {
    const r1 = await fetch(`${API}?api_key=${encodeURIComponent(clave)}`);
    const meta = await r1.json();
    if (!r1.ok || meta.estado !== 200 || !meta.datos) {
      const cad2 = caducidad(clave);
      const caducada = cad2 && cad2.dias < 0;
      return json({
        error: true,
        caducada: caducada || void 0,
        reason: caducada ? `La clave de AEMET caduc\xF3 el ${cad2.fecha}. Hay que pedir una nueva en opendata.aemet.es/centrodedescargas/obtencionAPIKey` : meta.descripcion || `AEMET respondi\xF3 ${r1.status}`
      }, 502);
    }
    const r2 = await fetch(meta.datos);
    if (!r2.ok) return json({ error: true, reason: `datos de AEMET: ${r2.status}` }, 502);
    const crudo = new TextDecoder("iso-8859-1").decode(await r2.arrayBuffer());
    const todas = JSON.parse(crudo);
    const porEstacion = /* @__PURE__ */ new Map();
    for (const o of todas) {
      if (typeof o.lat !== "number" || typeof o.lon !== "number") continue;
      const d = km(lat, lon, o.lat, o.lon);
      if (d > radio) continue;
      const ya = porEstacion.get(o.idema);
      if (!ya || String(o.fint || "") > String(ya.fint || "")) porEstacion.set(o.idema, { ...o, _km: d });
    }
    const ahora = Date.now();
    const estaciones = [...porEstacion.values()].sort((a, b) => a._km - b._km).slice(0, limite).map((o) => {
      const t = o.fint ? new Date(o.fint) : null;
      const minutos = t ? Math.round((ahora - t.getTime()) / 6e4) : null;
      const kmh = (v) => typeof v === "number" ? Math.round(v * 3.6 * 10) / 10 : null;
      return {
        id: o.idema,
        nombre: o.ubi ?? o.idema,
        km: Math.round(o._km * 10) / 10,
        altitud: typeof o.alt === "number" ? o.alt : null,
        viento: kmh(o.vv),
        racha: kmh(o.vmax),
        direccion: typeof o.dv === "number" ? o.dv : null,
        temperatura: typeof o.ta === "number" ? o.ta : null,
        humedad: typeof o.hr === "number" ? o.hr : null,
        lluvia: typeof o.prec === "number" ? o.prec : null,
        medidoEn: o.fint ?? null,
        haceMinutos: minutos
      };
    });
    const cad = caducidad(clave);
    return json({
      medido: true,
      fuente: "AEMET \xB7 observaci\xF3n convencional",
      // Aviso con un mes de antelación, para que no caduque a traición
      claveCaduca: cad && cad.dias <= 30 ? cad : void 0,
      unidades: { viento: "km/h", temperatura: "\xB0C", lluvia: "mm" },
      consultado: (/* @__PURE__ */ new Date()).toISOString(),
      estaciones
    }, 200);
  } catch (e) {
    return json({ error: true, reason: String(e.message || e) }, 502);
  }
};
function json(cuerpo, status) {
  const ok = status === 200;
  return new Response(JSON.stringify(cuerpo), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "access-control-allow-origin": "*",
      // Las estaciones publican cada hora: no tiene sentido pedirlo más.
      "cache-control": ok ? "public, max-age=300" : "no-store",
      "netlify-cdn-cache-control": ok ? "public, s-maxage=600, stale-while-revalidate=1800" : "no-store",
      "x-origen": "aemet-observacion"
    }
  });
}
var config = { path: "/estaciones" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
