var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/webcams.js
var webcams_exports = {};
__export(webcams_exports, {
  config: () => config,
  default: () => webcams_default
});
module.exports = __toCommonJS(webcams_exports);
var API = "https://api.windy.com/webcams/api/v3/webcams";
var num = (v, min, max, porDefecto) => {
  const n = Number(v);
  return Number.isFinite(n) && n >= min && n <= max ? n : porDefecto;
};
var webcams_default = async (request) => {
  const clave = process.env.WINDY_KEY;
  const p = new URL(request.url).searchParams;
  if (!clave) {
    return new Response(JSON.stringify({
      error: true,
      sinClave: true,
      reason: "Falta la clave de Windy en el servidor"
    }), { status: 503, headers: cabeceras(false) });
  }
  const lat = num(p.get("lat"), -90, 90, null);
  const lon = num(p.get("lon"), -180, 180, null);
  if (lat === null || lon === null) {
    return new Response(
      JSON.stringify({ error: true, reason: "faltan lat y lon" }),
      { status: 400, headers: cabeceras(false) }
    );
  }
  const radio = num(p.get("radio"), 1, 250, 60);
  const limite = num(p.get("limite"), 1, 50, 40);
  const url = new URL(API);
  url.searchParams.set("nearby", `${lat},${lon},${radio}`);
  url.searchParams.set("limit", String(limite));
  url.searchParams.set("include", "location,images,player,categories");
  url.searchParams.set("lang", "es");
  try {
    const r = await fetch(url, { headers: { "x-windy-api-key": clave, accept: "application/json" } });
    const cuerpo = await r.text();
    return new Response(cuerpo, { status: r.status, headers: cabeceras(r.ok) });
  } catch (e) {
    return new Response(
      JSON.stringify({ error: true, reason: String(e.message || e) }),
      { status: 502, headers: cabeceras(false) }
    );
  }
};
function cabeceras(ok) {
  return {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "cache-control": ok ? "public, max-age=300" : "no-store",
    "netlify-cdn-cache-control": ok ? "public, s-maxage=1800, stale-while-revalidate=3600" : "no-store",
    "x-origen": "windy-webcams"
  };
}
var config = { path: "/webcams" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
