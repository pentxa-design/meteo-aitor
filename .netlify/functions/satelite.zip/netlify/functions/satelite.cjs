var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/satelite.js
var satelite_exports = {};
__export(satelite_exports, {
  config: () => config,
  default: () => satelite_default
});
module.exports = __toCommonJS(satelite_exports);
var CAPS = "https://view.eumetsat.int/geoserver/wms?service=WMS&version=1.3.0&request=GetCapabilities";
var CAPAS = {
  ir: { wms: "msg_fes:ir108", nombre: "Sat\xE9lite infrarrojo" },
  convection: { wms: "msg_fes:rgb_convection", nombre: "Sat\xE9lite tormentas" },
  visible: { wms: "msg_fes:rgb_eview", nombre: "Sat\xE9lite visible" }
};
function extraerTiempo(xml, capa) {
  const i = xml.indexOf(`<Name>${capa}</Name>`);
  if (i < 0) return null;
  const bloque = xml.slice(i, i + 4e3);
  const m = bloque.match(/<Dimension name="time"[^>]*>([^<]+)</);
  if (!m) return null;
  const partes = m[1].trim().split("/");
  if (partes.length < 3) return null;
  const fin = new Date(partes[1]);
  const paso = (partes[2].match(/PT(\d+)M/) || [])[1];
  if (isNaN(fin) || !paso) return null;
  return { fin: fin.toISOString(), pasoMin: Number(paso) };
}
var satelite_default = async (request) => {
  const p = new URL(request.url).searchParams;
  const n = Math.max(1, Math.min(24, Number(p.get("n")) || 12));
  try {
    const r = await fetch(CAPS, { headers: { accept: "text/xml" } });
    if (!r.ok) return json({ error: true, reason: `EUMETSAT respondi\xF3 ${r.status}` }, 502);
    const xml = await r.text();
    const capas = {};
    for (const [clave, def] of Object.entries(CAPAS)) {
      const t = extraerTiempo(xml, def.wms);
      if (!t) continue;
      const horas = [];
      const fin = new Date(t.fin).getTime();
      for (let k = n - 1; k >= 0; k--) horas.push(new Date(fin - k * t.pasoMin * 6e4).toISOString());
      capas[clave] = { wms: def.wms, nombre: def.nombre, pasoMin: t.pasoMin, horas };
    }
    if (!Object.keys(capas).length) return json({ error: true, reason: "EUMETSAT no declara ninguna capa" }, 502);
    return json({
      fuente: "EUMETSAT \xB7 EUMETView (Meteosat)",
      wms: "https://view.eumetsat.int/geoserver/wms",
      consultado: (/* @__PURE__ */ new Date()).toISOString(),
      capas
    }, 200);
  } catch (e) {
    return json({ error: true, reason: String(e.message || e) }, 502);
  }
};
function json(cuerpo, status) {
  const ok = status === 200;
  return new Response(JSON.stringify(cuerpo), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "access-control-allow-origin": "*",
      // Publican cada 10-15 min: no tiene sentido releer el catálogo más.
      "cache-control": ok ? "public, max-age=180" : "no-store",
      "netlify-cdn-cache-control": ok ? "public, s-maxage=420, stale-while-revalidate=1800" : "no-store",
      "x-origen": "eumetsat-catalogo"
    }
  });
}
var config = { path: "/satelite" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
